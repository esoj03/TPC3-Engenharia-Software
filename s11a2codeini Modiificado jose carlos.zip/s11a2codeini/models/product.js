const Sequelize = require('sequelize');
const conexaoDB = require('../util/database');

const Produto = conexaoDB.define('produto', {
  id: {
    type: Sequelize.INTEGER,
    allowNull: false,
    autoIncrement: true,
    primaryKey: true,
  },

  title: Sequelize.STRING,

  price: {
    type: Sequelize.DOUBLE,
    allowNull: false
  },
  
  imageURL: {
    type: Sequelize.TEXT,
    allowNull: true
  },

  description: {
    type: Sequelize.STRING,
    allowNull:false
  },

});


module.exports = Produto;